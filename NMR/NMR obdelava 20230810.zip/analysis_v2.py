print("Loaded analysis_v2.py. This is now obsolete - it was split into multiple files. ")

from analysis_FID_v2 import *
from analysis_T1_v2 import *
from analysis_T2_v2 import *
from analysis_gluespc_v2 import *
from analysis_remainder_v2 import *